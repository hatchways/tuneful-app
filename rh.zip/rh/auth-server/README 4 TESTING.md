# Spotify Accounts Authentication Examples

TO RUN SERVER
node authorization_code/app.js
