﻿import React, { Component, Fragment } from 'react';
import logo from './logo.svg';
import './App.css';

import Left from './Components/Layouts/Left'
import Right from './Components/Layouts/Right'

import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';


import Container from '@material-ui/core/Container';


import Profile from './instapaper/pages/instapaper/Profile'


import Spotify from 'spotify-web-api-js';

const spotifyApi = new Spotify();
var stringInput = '';




export default class App extends Component {
      //var stringInput = "";

      constructor(){
        super();
        const params = this.getHashParams();
        const token = params.access_token;
        if (token) {
          spotifyApi.setAccessToken(token);
        }
        this.state = {
          loggedIn: token ? true : false,
          nowPlaying: { name: 'Not Checked', albumArt: '' }
        }
      }
      getHashParams() {
        var hashParams = {};
        var e, r = /([^&;=]+)=?([^&;]*)/g,
            q = window.location.hash.substring(1);
        e = r.exec(q)
        while (e) {
           hashParams[e[1]] = decodeURIComponent(e[2]);
           e = r.exec(q);
        }
        return hashParams;
      }

      getNowPlaying(){
        spotifyApi.getMyCurrentPlaybackState()
          .then((response) => {
            this.setState({
              nowPlaying: { 
                  name: response.item.name, 
                  albumArt: response.item.album.images[0].url
                }
            });
          })
      }

      searchForTracks(stringInput){
        spotifyApi.searchTracks(stringInput)
          .then((response) => {
            console.log(response.tracks.items[0].artists[0].name)
            console.log(response.tracks.items[0].name)
            console.log(response.tracks.items[0].id)
            console.log(response.tracks.items[0].album.images[0].url)
          })
      }



    render() {
        return (
            <Fragment>
            &nbsp;

            <Profile />

            &nbsp;


          Now Playing: { this.state.nowPlaying.name }



          <img src={this.state.nowPlaying.albumArt} style={{ height: 150 }}/>

        { this.state.loggedIn &&
          <button onClick={() => this.getNowPlaying()}>
            Check Now Playing
          </button>
        }

        { this.state.loggedIn &&
          <button onClick={() => this.searchForTracks('Fall')}>
            Search for Love
          </button>
        }






      </Fragment>
        );
    }
}





/*
export default class extends Component {
    render() {
        return <Fragment>
            <Left />

            <Right />
        </Fragment>
    }
}

function App() {
  return (
      <h1> Hello World </h1>
  );
  }





<Container maxWidth="lg">
    <Grid container>
        <Grid item lg spacing={2}>
            <Left />
        </Grid>
        <Grid item lg spacing={2}>
            <Profile />
        </Grid>
    </Grid>
</Container>


            <div> Now Playing: { this.state.nowPlaying.name} </div>

            <img src = { this.state.nowPlaying.image }/>
            
            <button onClick={() => this.getNowPlaying()}>
                Check Now Playing
            </button>

                constructor(){
        super();
        const params= this.getHashParams();
        this.state = {
            loggedIn: params.access_tokens ? true : false,
            nowPlaying: {
                name: 'Not Checked',
                image: ''
            }
        }
        if (params.access_tokens){
            spotifyWebApi.setAccessToken(params.access_tokens)
        }
    }

    getHashParams() {
      var hashParams = {};
      var e, r = /([^&;=]+)=?([^&;]*)/g,
          q = window.location.hash.substring(1);
      while ( e = r.exec(q)) {
         hashParams[e[1]] = decodeURIComponent(e[2]);
      }
      return hashParams;
    }

    getNowPlaying(){
        spotifyWebApi.getMyCurrentPlaybackState()
            .then((response) => {
                this.setState( {
                    nowPlaying: {
                        name: response.item.name,
                        image: response.item.album.image[0].url
                    }
                })
            })
    }
*/

//export default App;
