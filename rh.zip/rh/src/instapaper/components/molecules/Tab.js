import MuiTab from '@material-ui/core/Tab';

export default MuiTab;
