import MuiTabs from '@material-ui/core/Tabs';

export default MuiTabs;
