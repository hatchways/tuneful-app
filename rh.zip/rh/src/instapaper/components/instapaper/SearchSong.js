import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';




import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';
import theme from '../../theme/instapaper/theme';
import Slide from '@material-ui/core/Slide';

import App from '../../../App'

import Spotify from 'spotify-web-api-js';

import { MyTable } from '../../../MyTable'

import Profile from '../../pages/instapaper/Profile'

import { songChosen  } from '../../pages/instapaper/Profile'

const spotifyApi = new Spotify();


const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />; 
    });

let data = ["", ""];

var searchList = []
var searchItems = {
    artistName: "",
    trackName: "",
    id: "",
    albumImage:""
}

interface Props {
  rows: Array<{
    artistName: string;
    trackName: string;
    id: string;
    albumImage: string;
  }>;
}

var songSelectedInfo = {
    artistName: "",
    trackName: "",
    id: "",
    albumImage:""

}

export default function SearchSong(props) {
    const [open, setOpen] = React.useState(false);

    const useStyles = makeStyles({
        editButton: {
            background: "#828282",
            color: "#fff",
            marginLeft: 0,
            marginTop: 12,
            [theme.breakpoints.up('sm')]: {
                marginLeft: 20,
                //  marginTop: 0,
            },
        },
        uploadPhotoButton: {
            marginTop: 12,
        }, uploadCaption: {
            marginTop: 10,
        }
    });

    const classes = useStyles();


    function handleClickOpen() {
        setOpen(true);
    }

    function handleClose() {
        setOpen(false);
    }

    function songSelected(songId1, artistName1, trackName1, albumImage1) {
        console.log(songId1);
        console.log(artistName1);
        console.log(trackName1);
        console.log(albumImage1);
        songChosen.songId = songId1;
        songChosen.artistName = artistName1;
        songChosen.trackName = trackName1;
        songChosen.albumImage = albumImage1;
        console.log(songChosen.albumImage);
        setOpen(false);
    }

    const submit = () => {
        //  console.log(data)
        props.changed(data)
        setOpen(false)
    }

    const handleChange = (e) => {
        data[0] = e.target.value;
        // console.log(data)
    }

    const handleUploadPhoto = (e) => {
        //console.log(e.target.files[0])
        //data[1] = e.target.files[0]
        data[1] = e.target.value;    
    }

    const [rows, setRows] = useState([{
            artistName: "",
            trackName: "",
            id: "",
            albumImage:""
    }]);


    function searchForTracks(stringInput){
        console.log(stringInput)
        spotifyApi.searchTracks(stringInput)
            .then((response) => {
                var i;
                searchList = []
                for (i = 0; i < 20; i++){
                    try {
                        searchList.push({

                        artistName: response.tracks.items[i].artists[0].name,
                        trackName: response.tracks.items[i].name,
                        id: response.tracks.items[i].id,
                        //albumImage: "<img src = " + response.tracks.items[i].album.images[0].url + " width=\"50\" height=\"50\" />"
                        albumImage: response.tracks.items[i].album.images[0].url
                        })
                    }
                    catch(error) {


                    }

                }
                setRows(currentRows => searchList) 

            })
    }


    return (
        <div>
            <Button className={classes.editButton} variant="outlined" onClick={handleClickOpen}>
                Change Song
      </Button>
            <Dialog TransitionComponent={Transition}
                open={open}
                onClose={handleClose}
                aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Search Track</DialogTitle>
                <DialogContent>
                    
                    <TextField
                        autoFocus
                        margin="dense"
                        id="desc"
                        label=""
                        type="text"
                        fullWidth
                        onChange={(e) => searchForTracks(e.target.value)}
                        
                    />

                    <input
                        accept="*"
                        className={classes.input}
                        style={{ display: 'none' }}
                        id="raised-button-file"
                        multiple
                        type="file"
                        onChange={handleUploadPhoto}
                        
                    />
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>Artist Name</TableCell>
                            <TableCell>Track Name</TableCell>
                            <TableCell>Album</TableCell>
                 
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {rows.map(row => (
                            <TableRow key={row.id} onClick={event => songSelected(row.id, row.artistName, row.trackName, row.albumImage)} >

                              <TableCell>{row.artistName}</TableCell>
                              <TableCell>{row.trackName}</TableCell>
                              <TableCell><img src = {row.albumImage} width='50' height='50' /></TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    

                                      

                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="primary">
                        Close
                    </Button>
          

                </DialogActions>
                
            </Dialog>
        </div>
    );
}

//<MyTable rows= {rows} />