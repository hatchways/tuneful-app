﻿import React, { Component, Fragment } from 'react';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import IconButton from '@material-ui/core/IconButton';
import CssBaseline from '@material-ui/core/CssBaseline';
import { makeStyles } from '@material-ui/core/styles';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import atoms from '../../components/atoms';
import molecules from '../../components/molecules';

import theme from '../../theme/instapaper/theme';
import withTheme from './withTheme';
import Box from '@material-ui/core/Box';

import clsx from 'clsx';
import TextField from '@material-ui/core/TextField';

import SearchSong from '../../components/instapaper/SearchSong'



const { Avatar, Icon, Typography } = atoms;
const { Tabs, Tab } = molecules;

const useStyles = makeStyles({
  editButton: {
    marginLeft: 0,
    marginTop: 12,
    [theme.breakpoints.up('sm')]: {
      marginLeft: 20,
      marginTop: 0,
    },
  },
  settings: {
    [theme.breakpoints.up('sm')]: {
      marginLeft: 5,
    },
  },
});

var songChosen = {
    songId: "",
    artistName: "",
    trackName: "",
    albumImage: "https://i.scdn.co/image/1ee2851cfa3c823cfde5c8d15e31fa82d71d4a2e",
    descrption: ""   

  }

export { songChosen };

const profileChange = (e) => {
  //grabs the data from EditProfile. It's an array, e[0] is the description text, and e[1] is the image file
  console.log('PROFILE CHANGE')
  console.log(e)
  
  //PUT TO DATABASE!!!!!!!!


}

export default function Profile(){

  const [tabIndex, setTabIndex] = React.useState(0);
  const classes = useStyles();
  const upSm = useMediaQuery(theme.breakpoints.up('sm'), { defaultMatches: true });


  return (
    <React.Fragment>
            <CssBaseline />   
      <Box component="main" maxWidth={935} margin="auto" padding="60px 20px 0">
         <Box mb="44px">
          <Typography component="h1" variant="h4" lightWeight> 
                      <b> Share your music</b>

                  </Typography>


          &ensp;
          <Grid container spacing={2}>

          <Grid item xs={10} sm container>
            <Grid item xs container direction="column" spacing={4}>
              <Grid item xs>
                <Typography gutterBottom variant="subtitle1">
                  <SearchSong
                    changed={profileChange}
                    desc={""}
                  />
                </Typography>

              </Grid>
              <Grid item>
                <Typography variant="body2" style={{ cursor: 'pointer' }}>
                  <h4><b>Add description:</b></h4><p></p>
                  


                  <TextField
                    id="outlined-multiline-static"
                    label="Description"
                    multiline
                    rows="4"
                    defaultValue="Write description here"
                    className={classes.textField}
                    margin="normal"
                    variant="outlined"
                  />
                </Typography>
              </Grid>
            </Grid>
              <Grid item xs={4}>
              <img
              alt="post"
              style={{ width: '100%' }}

              src = {songChosen.albumImage}
               />
            </Grid>
          </Grid>
          </Grid>



           
        </Box>

                                <a href = 'http://localhost:8888'><center><Button className={classes.editButton} variant="outlined" fullWidth={!upSm}>
                    <h1>Share</h1>
                  </Button></center> </a>

      </Box>
    </React.Fragment>
  )
}

//export default withTheme(theme)(Profile);

      //onst [tabIndex, setTabIndex] = React.useState(0);
  //const classes = useStyles();
  //const upSm = useMediaQuery(theme.breakpoints.up('sm'), { defaultMatches: true });



