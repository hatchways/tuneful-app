﻿import React from 'react'
import Grid from '@material-ui/core/Grid';

export default props =>
    <div>
        <img src = "https://amp.businessinsider.com/images/4f856853ecad04546200002a-320-239.jpg"/> 

        &nbsp;
        &nbsp;
        &nbsp;
        &nbsp;
        <Grid container>
            <Grid item lg spacing={2}>
                 Likes
            </Grid>
            <Grid item lg spacing={2}>
                 Spotify image
            </Grid>
        </Grid>
    </div>

        
    