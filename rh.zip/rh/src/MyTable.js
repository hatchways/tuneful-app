import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import SearchSong from './instapaper/components/instapaper/SearchSong'


interface Props {
  rows: Array<{
    artistName: string;
    trackName: string;
    id: string;
    albumImage: string;
  }>;
}


export function MyTable({rows}: Props) {


  return (
    <Paper>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Artist Name</TableCell>
            <TableCell>Track Name</TableCell>
            <TableCell>Album</TableCell>
 
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map(row => (
            <TableRow key={row.id} onClick={event => console.log(row.id)} >

              <TableCell>{row.artistName}</TableCell>
              <TableCell>{row.trackName}</TableCell>
              <TableCell><img src = {row.albumImage} width='50' height='50' /></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
}

// <TableCell><img src = {row.albumImage} width='50' height='50' /></TableCell>
//<TableCell>{row.albumImage} </TableCell>